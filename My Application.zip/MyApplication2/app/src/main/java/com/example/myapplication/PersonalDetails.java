package com.example.myapplication;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.tabs.TabLayout;

public class PersonalDetails extends Fragment {


    private TabLayout tabLayout;
    private ViewPager viewPager;



    public PersonalDetails() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_personal_details,container,false);
        tabLayout = v.findViewById(R.id.tablayout);
        viewPager = v.findViewById(R.id.viewpager);

        tabLayout.setupWithViewPager(viewPager);

        PersonalDetailsAdapter personalDetailsAdapter = new PersonalDetailsAdapter(getChildFragmentManager(), FragmentPagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        personalDetailsAdapter.addFragment(new PersonalDetailsFragment(),"PersonalDetails");
        personalDetailsAdapter.addFragment(new EducationalDetailsFragment(),"EducationalDetails");
        viewPager.setAdapter(personalDetailsAdapter);


        return v;   }
}
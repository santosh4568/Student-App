package com.example.myapplication;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.tabs.TabLayout;

public class Academics extends Fragment {


    private TabLayout tabLayout;
    private ViewPager viewPager;



    public Academics() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_academics, container, false);
        tabLayout = v.findViewById(R.id.tablayout);
        viewPager = v.findViewById(R.id.viewpager);

        tabLayout.setupWithViewPager(viewPager);

        AcademicsAdapter academicsAdapter = new AcademicsAdapter(getChildFragmentManager(), FragmentPagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        academicsAdapter.addFragment(new WeeklyFragment(),"WEEKLY");
        academicsAdapter.addFragment(new MidTermFragment(),"MID TERM");
        viewPager.setAdapter(academicsAdapter);


        return v;   }
}
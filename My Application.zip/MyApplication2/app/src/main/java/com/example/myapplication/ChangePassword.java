package com.example.myapplication;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

public class ChangePassword extends Fragment {
    Button update;
        EditText c1,c2,c3;


    public ChangePassword() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v= inflater.inflate(R.layout.fragment_change_password, container, false);
        update=v.findViewById(R.id.update);
        c1=v.findViewById(R.id.c1);
        c2=v.findViewById(R.id.c2);
        c3=v.findViewById(R.id.c3);
        c1.addTextChangedListener(sub);
        c2.addTextChangedListener(sub);
        c3.addTextChangedListener(sub);
        return v;
    }
    private TextWatcher sub=new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            String s1=c1.getText().toString().trim();
            String s2=c2.getText().toString().trim();
            String s3=c3.getText().toString().trim();
            update.setEnabled(!s1.isEmpty() && !s2.isEmpty() && !s3.isEmpty() );

        }

        @Override
        public void afterTextChanged(Editable editable) {

        }
    };

}